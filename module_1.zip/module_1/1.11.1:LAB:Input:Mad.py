#Read a value from  a user and store the value in first_name
first_name = input("Enter your first name")

#TODO:Type your code to read three more values here
generic_location = input("Enter a generic location")
whole_number = input("Pick a whole number")
plural_noun = input("Choose a plural noun")

# Outputs/a short story using the four input values.Do  not modify the code below
print(first_name, 'went to', generic_location, 'to buy', whole_number, 'different types of', plural_noun)
