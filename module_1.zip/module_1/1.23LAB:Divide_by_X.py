'''Type your code here.'''
# Create variables for two user inputs
user_num = int(input())
x = int(input())

# Divide user_num by x three times
result1 = user_num // x
result2 = result1 // x
result3 = result2 // x

# Output the results
print(result1, result2, result3)